<?php
$id = $_POST['id'];
$conn = mysqli_connect("localhost", "root","", "ticket");
$query ="delete into customer(id)values( '$id')";
$result = mysqli_query($conn, $query);
if($result)
  echo 'Thank you for your cancel. We\' l appreciate!';
else
die("Something terrible happened. Please try again. ");
?>

